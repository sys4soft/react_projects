import React from "react";

const ComponenteDois = () => {
    return (
        <div className="componente">
            <p>Título: Componente dois</p>
        </div>
    )
}

export default ComponenteDois