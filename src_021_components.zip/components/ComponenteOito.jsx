import React from "react";

export default function(props) {

    function condicao(){
        switch (props.valor) {
            case "Joao":
                return <p>É o meu nome</p>
                break;
            case "Ana":
                return <p>É o nome da minha irmã</p>
                break;
            default:
                return <p>Desconheço quem tenha esse nome</p>
                break;
        }
    }

    return(
        <div className="componente">
            <p className="titulo">Título: {props.titulo}</p>
            {condicao()}
        </div>
    )
}