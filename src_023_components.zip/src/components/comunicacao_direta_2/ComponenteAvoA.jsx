import React from "react"

import ComponentePaiA from "./ComponentePaiA"

export default (props) => {
    return (
        <div>
            <p>Avô</p>
            <ComponentePaiA nome="joaquim" apelido="silva"/>
        </div>
    )
}