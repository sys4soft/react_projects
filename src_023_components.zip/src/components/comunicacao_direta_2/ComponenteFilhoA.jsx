import React from "react"

export default (props) => {
    return (
        <div>
            <p>Filho: {props.nome} {props.apelido}</p>
        </div>
    )
}