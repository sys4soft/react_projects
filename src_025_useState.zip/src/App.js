import React, { useState } from 'react'

export default function App(){

    if(true){
        useState()
    }

    useState()
    useState()
    useState()

    return (
        <>
            <h1>React Hooks</h1>
        </>
    )
}