const dados_clientes = [
    {id_cliente:1, nome: "joao", email: "joao@gmail.com"},
    {id_cliente:2, nome: "ana", email: "ana@gmail.com"},
    {id_cliente:3, nome: "carlos", email: "carlos@gmail.com"},
    {id_cliente:4, nome: "jorge", email: "jorge@gmail.com"},
    {id_cliente:5, nome: "marta", email: "marta@gmail.com"}
]

export default dados_clientes