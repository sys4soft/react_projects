import React from "react";

export default (props) =>
    <div className="componente">
        <p>Título: {props.titulo}</p>
    </div>