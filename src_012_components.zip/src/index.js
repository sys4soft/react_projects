import ReactDOM from "react-dom/client"

// app
import App from "./App"

const root = document.querySelector("#root")
ReactDOM.createRoot(root).render(<App />)