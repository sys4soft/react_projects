import React from "react";

const ComponenteDois = () => {
    return (
        <div className="componente">
            <p className="titulo">Título: Componente dois</p>
        </div>
    )
}

export default ComponenteDois