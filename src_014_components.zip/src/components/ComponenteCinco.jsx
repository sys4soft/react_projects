import React from "react";

const ComponenteCinco = (props) => {
    return (
        <>
            <p>Texto: {props.texto}</p>
        </>
    )
}

export default ComponenteCinco