import React from "react";

function ComponenteUm() {
    return (
        <div className="componente">
            <p className="titulo">Título: Componente um</p>
            <p>Componente mais simples de React.</p>
        </div>
    )
}

export default ComponenteUm