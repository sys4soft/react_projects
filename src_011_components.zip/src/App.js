import React from "react"
import './App.css'

// componentes
import ComponenteUm from "./components/ComponenteUm"

function App(){
    return (
        <>
            <ComponenteUm />
        </>
    )
}

export default App